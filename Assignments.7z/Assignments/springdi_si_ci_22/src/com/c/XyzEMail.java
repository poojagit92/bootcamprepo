package com.c;

public class XyzEMail {
	
	private String mail;
	private int id;
	
	public XyzEMail(String mail, int id) {
		super();
		this.mail = mail;
		this.id = id;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void sendMail()
	{
		System.out.println("sending the mail.......");
	}
	
	public void recvMail()
	{
		System.out.println("receving the email....");
	}
}
