package com.c;
public class Employee {  
private int id;  
private String name; 
private double marks;
private String dept;
  


public Employee() {
	System.out.println("def cons");
}



public int getId() {
	return id;
}





public void setId(int id) {
	this.id = id;
}





public String getName() {
	return name;
}





public void setName(String name) {
	this.name = name;
}





public double getMarks() {
	return marks;
}





public void setMarks(double marks) {
	this.marks = marks;
}





public String getDept() {
	return dept;
}





public void setDept(String dept) {
	this.dept = dept;
}





public void show(){  
    System.out.println("stdnt id:"+id+" stdnt name:"+name+ "marks"+marks +"department"+dept);  
}  
  
}
