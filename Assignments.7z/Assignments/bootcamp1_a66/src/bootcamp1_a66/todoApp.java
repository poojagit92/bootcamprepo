package bootcamp1_a66;

public class todoApp extends Application {
	
	void open(){
		System.out.print("TodoApp.open()");
		}
		void close(){
		System.out.print("TodoApp.close()");
		}
		
		public static void main(String[] args)
		{
		Application app = new todoApp();
		app.open();
		}

}

