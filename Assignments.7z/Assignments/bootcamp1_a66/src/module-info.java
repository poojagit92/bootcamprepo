module bootcamp1_a66 {
	requires bootcamp1_a6;
	requires application;
}