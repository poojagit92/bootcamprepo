package bootcamp1_a6;


public class Application {

	Application(){
		
		System.out.println("inside constructor");
	}
		void open(){
			System.out.println("open method of application");
			
		}
		void close(){
			
			System.out.println("close method of application");
		}
	}
