package bootcamp1_a2;

public class outofmemory {

	public static void main(String[] args) {
		boolean x=true;
		int count=0;
		while(x)
		{
			count++;
			System.out.println("line before exception"+count);
		}

	}

}
