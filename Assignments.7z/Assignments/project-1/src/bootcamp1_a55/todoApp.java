
package bootcamp1_a55;

import bootcamp1_a5.Application;


public class todoApp extends Application {
	
	todoApp() { 
		super();
		
	}
	   public void open(){
		System.out.print("TodoApp.open()");
		}
	   public void close(){
		System.out.print("TodoApp.close()");
		}
		
		public static void main(String[] args)
		{
		Application app = new todoApp();
		app.open();
		}

}
