package bootcamp1_a1;

public class mainfrommain {
	 static int count=0;

	public static void main(String[] args) {
	
		count=count+1;
		System.out.println("print"+count);
		main(new String[1]);

	}

}
