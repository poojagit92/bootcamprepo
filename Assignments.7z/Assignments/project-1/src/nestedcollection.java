import java.util.*;
public class nestedcollection {
	
	//Arraylist<String> ar =new Arraylist();

	public static void main(String[] args) {
		

	}

}
