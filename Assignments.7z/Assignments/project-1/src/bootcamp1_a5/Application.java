package bootcamp1_a5;


public class Application {

	protected Application(){
		
		System.out.println("inside constructor");
	}
		public void open(){
			System.out.println("open method of application");
			
		}
		public void close(){
			
			System.out.println("close method of application");
		}
	}
