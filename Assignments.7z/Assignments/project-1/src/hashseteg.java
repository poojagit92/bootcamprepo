import java.util.HashSet;
import java.util.Set;

public class hashseteg {

	
	private int accnum;
	private String name;
	
	
	
	public hashseteg(int accnum, String name) {
		
		this.accnum = accnum;
		this.name = name;
	}

	public int getAccnum() {
		return accnum;
	}

	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
	class hashset{
	public static void main(String[] args) {
		Set<hashseteg> hsa = new HashSet<>();
		hsa.add( new hashseteg(111,"n1"));
		hsa.add( new hashseteg(222,"n2"));
		hsa.add( new hashseteg(333,"n3"));
		

	}
	}

