package bootcamp1_a3;

public class methodchainingusingthis {
	
	public methodchainingusingthis t1() {
		
		System.out.println("t1 is invoked");
		return this;
		
	}
	public methodchainingusingthis t2() {
		
		System.out.println("t2 is invoked");
		return this;
		
	}
	public methodchainingusingthis t3() {
		
		System.out.println("t3 is invoked");
		return this;
		
	}

	public static void main(String[] args) {
		 new methodchainingusingthis().t1().t2().t3();

	}

}
