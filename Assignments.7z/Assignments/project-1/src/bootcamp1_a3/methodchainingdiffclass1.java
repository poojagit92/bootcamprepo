package bootcamp1_a3;

public class methodchainingdiffclass1 {

public methodchainingdiffclass1 t11() {
		
		System.out.println("t11 is invoked");
		methodchainingdiffclass m= new methodchainingdiffclass(1);
		m.sum(2).print();
		return this;
		
	}

public methodchainingdiffclass1 t12() {
	
	System.out.println("t12 is invoked");
	
	return this;
	
}
	
	
	public static void main(String[] args) {
		methodchainingdiffclass1 m1= new methodchainingdiffclass1();
		m1.t11().t12();
		
		

	}

}
