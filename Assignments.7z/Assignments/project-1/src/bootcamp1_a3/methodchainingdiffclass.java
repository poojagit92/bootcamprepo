package bootcamp1_a3;

public class methodchainingdiffclass {
	
	private int n;
	
	 methodchainingdiffclass(int numm) {
		n=numm;
	}
	
	public methodchainingdiffclass sum(int s) {
		n=s+n;
		return this;
	}

	public void print()  
	{  
	System.out.println(n);  
	}  

}
