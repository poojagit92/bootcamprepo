class TableA{  
  
	//prints multiplication table of a given int
static synchronized void printTable(int n){  
	 System.out.println("----------starting multiples of:"+n);
   for(int i=1;i<=10;i++){  
     System.out.println("multiple of:"+n +" is "+n*i);  
     try{  
       Thread.sleep(500);  
     }catch(Exception e){ System.out.println(e);}  
   }  
   System.out.println("----------ending multiples of:"+n);
 }  
}  
  
class MyThread1A extends Thread{  
	public void run(){  
	TableA.printTable(1);  
	}  
}  
  
class MyThread2A extends Thread{  
	public void run(){  
	TableA.printTable(10);  
	}  
} 