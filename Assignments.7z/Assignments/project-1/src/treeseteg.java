import java.util.*;
public class treeseteg {

	public static void main(String[] args) {
		TreeSet<city> ts = new TreeSet<>((city1,city2)->city1.getPopulation()-city2.getPopulation());;
		ts.add(new city("a",15));
		ts.add(new city("b",12));
		ts.add(new city("c",13));
		ts.add(new city("d",14));
		
		Set<city> t =Collections.synchronizedSet(ts);
		
		for(city c:ts)
		{
			System.out.println(c);
		}

	}

}
