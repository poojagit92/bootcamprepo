import java.util.*;
public class twoduplicate {

	public static void main(String[] args) {
		List<Integer> l= Arrays.asList(1,2,2,2,3,4,4,5,5,4);
		List<Integer> l2 = new ArrayList<>();
		Set<Integer> s= new HashSet<>(l);
		int count=0;
		int countd=0;
		for(int a:l)
		{
			if(s.contains(a))
			{
				count++;
			}
		
			if(count>1)
			{
				System.out.println("duplicate element found" +a);
				
			}
			else
			{
				l2.add(a);
			}
			
		}
		
	}

}
