package bootcamp4_a1;

public class multithreading {

}
