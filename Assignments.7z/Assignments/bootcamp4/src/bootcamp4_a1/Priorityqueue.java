package bootcamp4_a1;

public class Priorityqueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
