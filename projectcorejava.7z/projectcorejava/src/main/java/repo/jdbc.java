package repo;

import java.util.LinkedList;
import java.util.List;

import model.BankAccount;
import model.Transaction;

import java.sql.*;

public class jdbc {
	
	// TODo read from config file.
	
	
	public boolean login(String username,String password)
	{
		Connection ct= null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 ct= DriverManager.getConnection("jdbc:mysql://localhost:3306/pooja", "root", "DataGuard432$");
			// TODO check for ct if not null then only go ahead
			 st=ct.prepareStatement("select username,password from bankaccount where username =? and password =? ");
			st.setString(1, username);
			st.setString(2, password);
			 rs = st.executeQuery();
			return rs.next();
		}
		catch(SQLException e){
			System.out.println(e.getLocalizedMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				rs.close();
				st.close();
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return false;
	}
	
	public List<Transaction> view(String username)
	{
		
		Connection ct= null;
		PreparedStatement st = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 ct = DriverManager.getConnection("jdbc:mysql://localhost:3306/pooja", "root", "DataGuard432$");
			
			 st=ct.prepareStatement("select *   from transactions where username =? ");
			st.setString(1, username);
			 rs = st.executeQuery();
			List<Transaction> result = new LinkedList<Transaction>();
			while(rs.next())
			{
				// map resultset to object, add to list and return;
				//return null;
			}
			return result;
		}
		catch(SQLException e){
			System.out.println(e.getLocalizedMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				rs.close();
				st.close();
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return null;
	}
	
	public boolean create(BankAccount b)
	{
		Connection ct= null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 ct= DriverManager.getConnection("jdbc:mysql://localhost:3306/pooja", "root", "DataGuard432$");
			// TODO check for ct if not null then only go ahead
			st=ct.prepareStatement("insert into bankaccount ...to complete");
			// TODO map object
			return st.executeUpdate() >=1;
		}
		catch(SQLException e){
			System.out.println(e.getLocalizedMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				rs.close();
				st.close();
				ct.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return false;
	}
	

}
