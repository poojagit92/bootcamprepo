package repo;

import model.Transaction;

public class TransactionsRepo {
	
	public Transaction view(String username)
	{
		return null;
		
	}
	public void transfer(int amount,String username)
	{
		
	}

}
