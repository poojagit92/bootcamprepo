package repo;

import java.util.ArrayList;
import java.util.List;

import model.Transaction;

public class TransactionsRepo {
	jdbc j= new jdbc();
	
	public List<Transaction> view(String username)
	{
		List<Transaction> t =  new ArrayList<Transaction>();
		t=j.view(username);
		return t;
		
	}
	public void transfer(int amount,String username)
	{
		j.transfer(username, amount);
	}

}
