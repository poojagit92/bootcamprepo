package repo;

import model.BankAccount;

public class BankAccountRepo {
	jdbc l= new jdbc();
	
	public boolean login(String username,String password)
	{
		boolean s=l.login(username, password);
		return s;
	}

	public void create(BankAccount b) {
		
		l.create(b);
	}
	
	public void updateContact(String username, int contact) {
		
		l.updateContact(username, contact);
}
	
	public int viewBalance(String username)
	{
	int amount=	l.viewBalance(username);
		return amount;
		
	}
}