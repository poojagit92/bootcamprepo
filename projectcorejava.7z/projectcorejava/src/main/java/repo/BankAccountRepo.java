package repo;

import model.BankAccount;

public class BankAccountRepo {
	
	public boolean login(String username,String password)
	{
		return true;
	}

	public void create(BankAccount b) {
		
		
	}
}
