package service;

import java.util.ArrayList;
import java.util.List;

import model.Transaction;
import repo.TransactionsRepo;

public class TransactionsService {
	TransactionsRepo trp=new TransactionsRepo();
	
	
	public List<Transaction> view(String username)
	{
		List<Transaction> s= new ArrayList<Transaction>();
		return s=trp.view(username);
	}
	public void transfer(int amount, String username) {
		trp.transfer(amount, username);
		
	}
	
		
	}


