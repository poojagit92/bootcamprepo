package service;

import model.Transaction;
import repo.TransactionsRepo;

public class TransactionsService {
	TransactionsRepo trp=new TransactionsRepo();
	
	
	public Transaction view(String username)
	{
		Transaction s= new Transaction();
		s=trp.view(username);
	}
	public void transfer(int amount, String username) {
		// TODO Auto-generated method stub
		
	}

}
