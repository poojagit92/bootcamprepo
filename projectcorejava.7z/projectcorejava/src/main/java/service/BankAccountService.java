package service;

import model.BankAccount;
import repo.BankAccountRepo;
import repo.TransactionsRepo;

public class BankAccountService {
	BankAccountRepo brp=new BankAccountRepo();
	
	public boolean login(String username,String password)
	{
		boolean b= brp.login(username, password);
		return b;
	}
	public void create(BankAccount b)
	{
		brp.create(b);
	}
	public void updateContact(String username, int contact) {
		brp.updateContact(username, contact);
		
	}
	public int viewBalance(String username)
	{
		return brp.viewBalance(username);
	}

}
