package projectcorejava;

import java.util.Scanner;

import controller.BankingSoftwareController;
import model.BankAccount;

public class BankingSoftware {
	final static boolean authenticated = false;
	
	public static void main(String args[])

	{
		BankingSoftwareController b = new BankingSoftwareController();
		System.out.println("Please Choose one of the option from below :"
				+"#1. Login"
				+"#2. Create Bank Account"
				+"#3. View Transactions"
				+"#4. Transfer"
				+"#5. Exit");			
		Scanner s = new Scanner(System.in);
		int st=Integer.parseInt(s.nextLine());
		// 
		
		switch(st) {
		case 1: {
				System.out.println("Please enter username");
				String u=s.nextLine();
				System.out.println("Please enter password");
				String p=s.nextLine();
				authenticated= b.login(u,p);
				break;
				}
		case 2:{
			if (authenticated) {
				
			BankAccount b1 = new BankAccount();
			b1.setAadhar(s.nextInt());
			b1.setBalance(s.nextInt());
			b1.setDOB();// will change datatype to string
			b1.setEmail(s.nextLine());
			b1.setMobilen(s.nextInt());
			b1.setName(s.nextLine());
			b1.setPAN(s.nextInt());
			b1.setPostalAddr(s.nextLine());
			b.createAccount(b1);
			}
			break;
		}
		case 3:
		{
			if(authenticated) {
			System.out.println("Please enter username to view transactions");
			String username=s.nextLine();
			b.view(username);}
			break;
		}
		case 4:
		{
			if(authenticated) {
			System.out.println("Please enter username to initiate transfer for");
			String username=s.nextLine();
			System.out.println("Please enter amount to transfer");
			int a= s.nextInt();
			b.transfer(a,username);}
			break;
		}
		case 5:
		{
			break;
		}
		}
	}
}
