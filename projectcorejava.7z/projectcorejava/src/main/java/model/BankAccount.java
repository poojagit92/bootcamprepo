package model;

import java.util.Date;

public class BankAccount {
	
	private String name;
	private String username;
	// Store hash of the password. if time permits.
	private String password;
	private String email;
	private int mobilen;
	private String DOB;
	private int PAN;
	private int aadhar;
	private String postalAddr;
	private int balance;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMobilen() {
		return mobilen;
	}
	public void setMobilen(int mobilen) {
		this.mobilen = mobilen;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public int getPAN() {
		return PAN;
	}
	public void setPAN(int pAN) {
		PAN = pAN;
	}
	public int getAadhar() {
		return aadhar;
	}
	public void setAadhar(int aadhar) {
		this.aadhar = aadhar;
	}
	public String getPostalAddr() {
		return postalAddr;
	}
	public void setPostalAddr(String postalAddr) {
		this.postalAddr = postalAddr;
	}
	public BankAccount(String name, String username, String password, String email, int mobilen, String dOB, int pAN,
			int aadhar, String postalAddr) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
		this.email = email;
		this.mobilen = mobilen;
		DOB = dOB;
		PAN = pAN;
		this.aadhar = aadhar;
		this.postalAddr = postalAddr;
		this.balance=balance;
	}
	
	public BankAccount() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BankAccount [name=" + name + ", username=" + username + ", password=" + password + ", email=" + email
				+ ", mobilen=" + mobilen + ", DOB=" + DOB + ", PAN=" + PAN + ", aadhar=" + aadhar + ", postalAddr="
				+ postalAddr + ", balance=" + balance + "]";
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	
}
