package controller;

import java.util.ArrayList;
import java.util.List;

import model.BankAccount;
import model.Transaction;
import service.BankAccountService;
import service.TransactionsService;

public class BankingSoftwareController {

	// public method for login, view, create, and transfer.
	BankAccountService bs= new BankAccountService();
	TransactionsService ts=new TransactionsService();
	public boolean login(String username,String password)
	{
		
		if(username!=null && password!=null)
		{
			boolean b= bs.login(username,password);
			if(b==true)
			{
			System.out.println("logged in successfully");
			return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			System.out.println("login unccessfull");
			return false;
		}
	}
	
	public List<Transaction> view(String username)
	{
		List<Transaction> s= new ArrayList<Transaction>();
		return s=ts.view(username);
	}
	public  void createAccount(BankAccount b)
	{ // TODO input validation for domain data?
		bs.create(b);
	}
	public void transfer(int amount,String username)
	{
		ts.transfer(amount,username);
	}
	public void updateContact(String username,int contact)
	{
		bs.updateContact(username,contact);
	}
	public int viewBalance(String username)
	{
		return bs.viewBalance(username);
	}
}
