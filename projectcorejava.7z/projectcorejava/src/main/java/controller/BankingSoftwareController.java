package controller;

import model.BankAccount;
import model.Transaction;
import service.BankAccountService;
import service.TransactionsService;

public class BankingSoftwareController {

	// public method for login, view, create, and transfer.
	BankAccountService bs= new BankAccountService();
	TransactionsService ts=new TransactionsService();
	public boolean login(String username,String password)
	{
		
		if(username!=null && password!=null)
		{
			boolean b= bs.login(username,password);
			if(b==true)
			{
			System.out.println("logged in successfully");
			return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			System.out.println("login unccessfull");
			return false;
		}
	}
	
	public Transaction view(String username)
	{
		Transaction s= new Transaction();
		return s=ts.view(username);
	}
	public  void createAccount(BankAccount b)
	{ // TODO input validation for domain data?
		bs.create(b);
	}
	public void transfer(int amount,String username)
	{
		ts.transfer(amount,username);
	}
}
